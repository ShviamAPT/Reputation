#/bin/bash

pytest -v tests/test_utils.py
